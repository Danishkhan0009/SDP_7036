# Task 6 results - per-stage fmax on GPDK045 (gsclib045 v4.4, slow_vdd1v0 = 0.9 V 125 C)

Tools: Genus 21.14, Xcelium 22.09 (cadence44/47). No wire-load model in the library (net area 0),
so decision limits carry a 1.25x margin: <= 2.0 ns for DDR5-3200 (400 MHz), <= 1.33 ns for DDR5-4800 (600 MHz).

| Run | Config | Target ns | Stage ns | fmax MHz | Cell area um2 | Critical path starts at |
|---|---|---|---|---|---|---|
| v3 | enc, LUT S-box | 1.25 | 1.592 | 628 | 26,901 | data register |
| v3 | enc, tower S-box | 1.25 | 2.924 | 342 | 15,854 | data register |
| v3 | enc+dec, LUT | 1.25 | 2.454 | 407 | 43,845 | direction flop (fanout 521) |
| v3 | enc+dec, tower | 1.25 | 3.814 | 262 | 26,072 | direction flop |
| v5 | enc lane | 1.25 | 1.554 | 644 | 30,256 | data register |
| v5 | dec lane | 1.25 | 1.820 | 549 | 31,365 | data register |
| v5 | enc+dec, dir per stage | 1.25 | 2.134 | 469 | 47,638 | direction flop |
| v5 | enc+dec, dir mode (MC) | 1.25 | 2.047 | 489 | 47,686 | data register |
| v5 | enc+dec, split round | 1.25 | 1.407 | 711 | 45,610 | data register |
| v5 | **enc+dec, dir mode (MC)** | **2.0** | **2.000** | **500** | **45,564** | data register |

RTL check: Xcelium tb_round / tb_round_v5 PASS (303 AES blocks, enc + dec, every config).

Decision (Spec Section 4): D36 DDR5-3200 at 400 MHz; D37 option A = 2 enc+dec lanes, LUT S-box,
round key one stage ahead, equivalent inverse cipher; D35 direction changes only with the lane empty;
D38 fallback A-split (1.407 ns) if the full engine misses 2.0 ns in PH7. DDR5-4800 dropped.
v3 -> v5 change of the enc+dec stage: 2.454 ns -> 2.047 ns (same 1.25 ns target).
