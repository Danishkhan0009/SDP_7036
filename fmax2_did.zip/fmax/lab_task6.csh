#!/bin/csh -f
# lab_task6.csh - Task 6 one-shot launcher for cadence47 (csh lab shell).
# Usage (from inside the fmax/ folder):   csh lab_task6.csh            full run
#                                         csh lab_task6.csh sim        Xcelium check only
#                                         csh lab_task6.csh syn        Genus only (skip sim)
source /home/install/cshrc
bash ./lab_task6.sh $argv
