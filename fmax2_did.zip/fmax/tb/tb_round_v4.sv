`timescale 1ns/1ps
// tb_round_v4.sv - full AES-128 by chaining v4 data stages with the key pipeline, all 3 modes.
module tb_round_v4;
  import aes_sbox_pkg::*;
  localparam int NV = `ifdef NV_OVR `NV_OVR `else 303 `endif;
  logic [511:0] vec [0:NV-1];
  int errors = 0;
  function automatic logic [7:0] RCON(input int i);
    case (i) 0: return 8'h01; 1: return 8'h02; 2: return 8'h04; 3: return 8'h08; 4: return 8'h10;
             5: return 8'h20; 6: return 8'h40; 7: return 8'h80; 8: return 8'h1b; default: return 8'h36; endcase
  endfunction
  function automatic string NAME(input int i);
    case (i) 0: return "v4 enc"; 1: return "v4 encdec"; default: return "v4 dec"; endcase
  endfunction
  logic dir; logic [127:0] s_in, k_in, rk_in; logic [7:0] rcon;
  logic [127:0] sm [3], sl [3], rko [3], dko [3];
  `define V4(i, M) \
    aes_dstage #(.MODE(M), .IS_LAST(0)) dm``i (.dir(dir), .s_in(s_in), .k_in(k_in), .s_out(sm[i])); \
    aes_dstage #(.MODE(M), .IS_LAST(1)) dl``i (.dir(dir), .s_in(s_in), .k_in(k_in), .s_out(sl[i])); \
    aes_kstep  #(.MODE(M)) ks``i (.dir(dir), .rk_in(rk_in), .rcon(rcon), .rk_out(rko[i]), .dk_out(dko[i]));
  `V4(0, 0)
  `V4(1, 1)
  `V4(2, 2)
  task automatic run(input int m, input logic d, input logic [127:0] key, rk10, din, output logic [127:0] dout);
    logic [127:0] s, rk, kk;
    dir = d;
    if (!d) begin
      s = din ^ key; rk = key;
      for (int r = 1; r <= 10; r++) begin
        rk_in = rk; rcon = RCON(r-1); #1; rk = rko[m];            // key pipeline: rk[r]
        s_in = s; k_in = rk; #1; s = (r == 10) ? sl[m] : sm[m];   // data uses registered rk[r]
      end
    end else begin
      s = din ^ rk10; rk = rk10;
      for (int r = 9; r >= 0; r--) begin
        rk_in = rk; rcon = RCON(r); #1; rk = rko[m];              // rk[r]
        rk_in = rk; #1; kk = (r == 0) ? rk : dko[m];              // InvMix(rk[r]) a stage later
        s_in = s; k_in = kk; #1; s = (r == 0) ? sl[m] : sm[m];
      end
      if (rk !== key) begin errors++; $display("FAIL %s inverse schedule", NAME(m)); end
    end
    dout = s;
  endtask
  initial begin
    logic [127:0] out; int be, bd;
    $readmemh("aes_blocks.hex", vec);
    for (int m = 0; m < 3; m++) begin
      be = 0; bd = 0;
      for (int v = 0; v < NV; v++) begin
        if (m != 2) begin run(m, 1'b0, vec[v][511:384], vec[v][383:256], vec[v][255:128], out); if (out !== vec[v][127:0]) be++; end
        if (m != 0) begin run(m, 1'b1, vec[v][511:384], vec[v][383:256], vec[v][127:0], out); if (out !== vec[v][255:128]) bd++; end
      end
      if (be + bd) $display("FAIL  %-10s enc errors %0d  dec errors %0d", NAME(m), be, bd);
      else         $display("PASS  %-10s %0d blocks (enc %s, dec %s)", NAME(m), NV, m != 2 ? "yes" : "n/a", m != 0 ? "yes" : "n/a");
      errors += be + bd;
    end
    if (errors) $display("ROUND_V4 FAIL (%0d)", errors); else $display("ROUND_V4 PASS");
    $finish;
  end
endmodule
