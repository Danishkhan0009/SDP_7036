`timescale 1ns/1ps
// tb_round_v5.sv - full AES-128 (303 blocks) through: v4 full stage (modes 0/1/2) and the v5 split stage (A then B),
// with the key-ahead pipeline. Also instantiates all 5 probe tops so Xcelium elaborates exactly what Genus reads.
module tb_round_v5;
  import aes_sbox_pkg::*;
  localparam int NV = `ifdef NV_OVR `NV_OVR `else 303 `endif;
  logic [511:0] vec [0:NV-1];
  int errors = 0;
  function automatic logic [7:0] RCON(input int i);
    case (i) 0: return 8'h01; 1: return 8'h02; 2: return 8'h04; 3: return 8'h08; 4: return 8'h10;
             5: return 8'h20; 6: return 8'h40; 7: return 8'h80; 8: return 8'h1b; default: return 8'h36; endcase
  endfunction
  function automatic string NAME(input int i);
    case (i) 0: return "full enc"; 1: return "full encdec"; 2: return "full dec"; default: return "split encdec"; endcase
  endfunction
  logic dir; logic [127:0] s_in, k_in, rk_in; logic [7:0] rcon;
  logic [127:0] sm [4], sl [4], rko [3], dko [3], mid_m, mid_l;
  `define V4(i, M) \
    aes_dstage #(.MODE(M), .IS_LAST(0)) dm``i (.dir(dir), .s_in(s_in), .k_in(k_in), .s_out(sm[i])); \
    aes_dstage #(.MODE(M), .IS_LAST(1)) dl``i (.dir(dir), .s_in(s_in), .k_in(k_in), .s_out(sl[i])); \
    aes_kstep  #(.MODE(M)) ks``i (.dir(dir), .rk_in(rk_in), .rcon(rcon), .rk_out(rko[i]), .dk_out(dko[i]));
  `V4(0, 0)
  `V4(1, 1)
  `V4(2, 2)
  aes_dstage_a #(.MODE(1))              sa  (.dir(dir), .s_in(s_in),   .s_mid(mid_m));
  aes_dstage_b #(.MODE(1), .IS_LAST(0)) sbm (.dir(dir), .s_mid(mid_m), .k_in(k_in), .s_out(sm[3]));
  aes_dstage_b #(.MODE(1), .IS_LAST(1)) sbl (.dir(dir), .s_mid(mid_m), .k_in(k_in), .s_out(sl[3]));
  // elaborate the Genus tops too (not driven; compile/elab check only)
  logic clk = 0; logic [127:0] po [15];
  probe5_encdec_mc t0 (.clk(clk), .dir_i(1'b0), .s_i('0), .k_i('0), .rk_i('0), .rcon_i('0), .s_o(po[0]),  .rk_o(po[1]),  .dk_o(po[2]));
  probe5_split_mc  t1 (.clk(clk), .dir_i(1'b0), .s_i('0), .k_i('0), .rk_i('0), .rcon_i('0), .s_o(po[3]),  .rk_o(po[4]),  .dk_o(po[5]));
  probe5_dec       t2 (.clk(clk), .dir_i(1'b0), .s_i('0), .k_i('0), .rk_i('0), .rcon_i('0), .s_o(po[6]),  .rk_o(po[7]),  .dk_o(po[8]));
  probe5_enc       t3 (.clk(clk), .dir_i(1'b0), .s_i('0), .k_i('0), .rk_i('0), .rcon_i('0), .s_o(po[9]),  .rk_o(po[10]), .dk_o(po[11]));
  probe5_encdec    t4 (.clk(clk), .dir_i(1'b0), .s_i('0), .k_i('0), .rk_i('0), .rcon_i('0), .s_o(po[12]), .rk_o(po[13]), .dk_o(po[14]));

  task automatic run(input int m, input logic d, input logic [127:0] key, rk10, din, output logic [127:0] dout);
    logic [127:0] s, rk, kk; int km;
    km = (m == 3) ? 1 : m; dir = d;
    if (!d) begin
      s = din ^ key; rk = key;
      for (int r = 1; r <= 10; r++) begin
        rk_in = rk; rcon = RCON(r-1); #1; rk = rko[km];
        s_in = s; k_in = rk; #1; s = (r == 10) ? sl[m] : sm[m];
      end
    end else begin
      s = din ^ rk10; rk = rk10;
      for (int r = 9; r >= 0; r--) begin
        rk_in = rk; rcon = RCON(r); #1; rk = rko[km];
        rk_in = rk; #1; kk = (r == 0) ? rk : dko[km];
        s_in = s; k_in = kk; #1; s = (r == 0) ? sl[m] : sm[m];
      end
      if (rk !== key) begin errors++; $display("FAIL %s inverse schedule", NAME(m)); end
    end
    dout = s;
  endtask
  initial begin
    logic [127:0] out; int be, bd;
    $readmemh("aes_blocks.hex", vec);
    for (int m = 0; m < 4; m++) begin
      be = 0; bd = 0;
      for (int v = 0; v < NV; v++) begin
        if (m != 2) begin run(m, 1'b0, vec[v][511:384], vec[v][383:256], vec[v][255:128], out); if (out !== vec[v][127:0]) be++; end
        if (m != 0) begin run(m, 1'b1, vec[v][511:384], vec[v][383:256], vec[v][127:0], out); if (out !== vec[v][255:128]) bd++; end
      end
      if (be + bd) $display("FAIL  %-12s enc errors %0d  dec errors %0d", NAME(m), be, bd);
      else         $display("PASS  %-12s %0d blocks", NAME(m), NV);
      errors += be + bd;
    end
    if (errors) $display("ROUND_V5 FAIL (%0d)", errors); else $display("ROUND_V5 PASS");
    $finish;
  end
endmodule
