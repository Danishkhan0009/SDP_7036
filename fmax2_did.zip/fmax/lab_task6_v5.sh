#!/bin/bash
# lab_task6.sh - Task 6 fmax probe, fully automated. Called by lab_task6.csh (tools already sourced).
# Stages: 0 preflight -> 1 Xcelium RTL check -> 2 Genus inputs -> 3 Genus x8 -> 4 summary -> 5 pack results
# Stops at the first failed stage. Everything is logged in logs/; results packed in ../fmax_results_v5.tgz
MODE="${1:-all}"
cd "$(dirname "$0")" || exit 1
mkdir -p logs out
ST=logs/STATUS.txt
: > "$ST"
say()  { echo "[$(date +%H:%M:%S)] $*" | tee -a "$ST"; }
die()  { say "STOP: $*"; say "Send Claude: logs/STATUS.txt + the log named above."; pack; exit 1; }
pack() { (cd .. && tar czf fmax_results_v5.tgz fmax/out fmax/logs fmax/dh_cells.tcl 2>/dev/null)
         say "Packed ../fmax_results_v5.tgz (upload this to Claude)"; }

LIB_DIR="${LIB_DIR:-/home/install/FOUNDRY/lan/flow/t1u1/reference_libs/GPDK045/gsclib045_all_v4.4/gsclib045/timing}"
LIB_FILE="${LIB_FILE:-slow_vdd1v0_basicCells.lib}"
LEF="${LEF:-/home/install/FOUNDRY/lan/flow/t1u1/reference_libs/GPDK045/gsclib045_all_v4.4/gsclib045/lef/gsclib045_macro.lef}"

# ---------------- 0 preflight
say "== Stage 0: preflight (mode=$MODE)"
for f in rtl/aes_sbox_pkg.sv rtl/aes_round_stage.sv rtl/aes_round_probe.sv tb/tb_round_v5.sv rtl/aes_round_v4.sv rtl/aes_round_v5.sv rtl/aes_probe_v5.sv \
         tb/aes_blocks.hex tb/sbox_expect.hex syn/genus_one.tcl syn/run_fmax.sh syn/parse_fmax.py; do
  [ -f "$f" ] || die "missing $f - run this from inside the unzipped fmax/ folder"
done
HAVE_PY=0; command -v python3 >/dev/null && HAVE_PY=1
say "tools: xrun=$(command -v xrun || echo MISSING) genus=$(command -v genus || echo MISSING) python3=$([ $HAVE_PY = 1 ] && echo yes || echo no)"
if [ "$MODE" != syn ]; then command -v xrun >/dev/null || die "xrun not found after cshrc (select Xcelium, then rerun)"; fi
if [ "$MODE" != sim ]; then
  command -v genus >/dev/null || die "genus not found after cshrc (select Genus, then rerun: csh lab_task6.csh syn)"
  [ -f "$LIB_DIR/$LIB_FILE" ] || die "library not found: $LIB_DIR/$LIB_FILE"
fi

# ---------------- 1 Xcelium RTL check
if [ "$MODE" != syn ]; then
  say "== Stage 1: Xcelium round-stage check (~2 min)"
  ( cd tb && xrun -sv ../rtl/aes_sbox_pkg.sv ../rtl/aes_round_v4.sv ../rtl/aes_round_v5.sv ../rtl/aes_probe_v5.sv \
       tb_round_v5.sv -top tb_round_v5 -timescale 1ns/1ps -l ../logs/round_xrun.log > /dev/null 2>&1 )
  grep -E "^(PASS|FAIL)|ROUND_V5" logs/round_xrun.log | tee -a "$ST"
  grep -q "ROUND_V5 PASS" logs/round_xrun.log || die "RTL check did not pass - see logs/round_xrun.log"
  say "Stage 1 OK"
  [ "$MODE" = sim ] && { pack; exit 0; }
fi

# ---------------- 2 Genus inputs
say "== Stage 2: Genus inputs"
export LIB_DIR LIB_FILE
if [ -f "$LEF" ]; then
  awk '/^MACRO/{m=$2} /SIZE/{if ($4+0 > 2.0) print "set_db [get_db lib_cells */" m "] .dont_use true"}' "$LEF" > dh_cells.tcl
  N=$(wc -l < dh_cells.tcl)
  if [ "$N" -eq 62 ]; then export DH_CELLS="$PWD/dh_cells.tcl"; say "dh_cells.tcl: 62 cells (used)"
  else unset DH_CELLS; say "dh_cells.tcl: $N cells, expected 62 - NOT used (fine for fmax)"; fi
else
  say "LEF not found ($LEF) - dh_cells skipped (fine for fmax)"
fi

# ---------------- 3 Genus x8
say "== Stage 3: Genus, 5 v5 configs x 1 period (~50 min), decisive runs first. Partial table after every run."
FAILS=0
for TOP in probe5_encdec_mc probe5_split_mc probe5_dec probe5_enc probe5_encdec; do
  for PERIOD_NS in 1.25; do
    export TOP PERIOD_NS
    say "   $TOP @ $PERIOD_NS ns ..."
    genus -batch -no_gui -files syn/genus_one.tcl -log logs/genus_${TOP}_${PERIOD_NS} > /dev/null 2>&1
    if grep -qs "FMAX_DONE" logs/genus_${TOP}_${PERIOD_NS}.log* && [ -s out/${TOP}_${PERIOD_NS}_timing.rpt ]; then
      say "   done"
      case "$TOP" in *_mc) grep -qs "MC_APPLIED" logs/genus_${TOP}_${PERIOD_NS}.log* || say "   WARNING: multicycle not applied for $TOP";; esac
      [ $HAVE_PY = 1 ] && python3 syn/parse_fmax.py out > logs/fmax_summary.txt 2>&1 && grep -E "^${TOP} " logs/fmax_summary.txt | tee -a "$ST"
    else
      FAILS=$((FAILS+1)); say "   FAILED - first errors:"
      grep -is "error" logs/genus_${TOP}_${PERIOD_NS}.log* | head -5 | tee -a "$ST"
      if [ "$FAILS" -ge 2 ] && [ -z "$(ls out/*_timing.rpt 2>/dev/null)" ]; then
        die "first two Genus runs both failed - same cause, no point running the rest"
      fi
    fi
  done
done
say "Stage 3 finished: $((5-FAILS))/5 runs OK"

# ---------------- 4 summary
say "== Stage 4: summary"
if [ $HAVE_PY = 1 ]; then
  python3 syn/parse_fmax.py out | tee logs/fmax_summary.txt | tee -a "$ST"
else
  say "python3 not available - Claude will parse out/*.rpt from the packed results"
fi

# ---------------- 5 pack
pack
say "ALL DONE. Upload ../fmax_results_v5.tgz to Claude."
