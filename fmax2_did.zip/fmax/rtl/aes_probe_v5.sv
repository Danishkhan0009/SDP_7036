`timescale 1ns/1ps
// aes_probe_v5.sv - every reg-to-reg path of one v5 lane stage (data + key-ahead pipeline).
//   DIR_REG = 1 : direction registered per stage (v4 style, high fanout, single-cycle)
//   DIR_REG = 0 : direction is a lane-wide mode port, changed only when the lane is empty (Spec D35);
//                 Genus applies set_multicycle_path 2 from port dir_i for tops named *_mc
//   SPLIT   = 1 : round split over two stages: A (shift + S-box) | B (mix + key XOR)
module aes_probe_v5 #(parameter int MODE = 1, parameter bit DIR_REG = 1, parameter bit SPLIT = 0) (
  input  logic clk, dir_i, input logic [127:0] s_i, k_i, rk_i, input logic [7:0] rcon_i,
  output logic [127:0] s_o, rk_o, dk_o);
  logic dir_q, dir; logic [127:0] s_q, k_q, rk_q, mid_q, mid_d, s_d, rk_d, dk_d; logic [7:0] rcon_q;
  always_ff @(posedge clk) begin
    dir_q <= dir_i; s_q <= s_i; k_q <= k_i; rk_q <= rk_i; rcon_q <= rcon_i;
    mid_q <= mid_d; s_o <= s_d; rk_o <= rk_d; dk_o <= dk_d;
  end
  assign dir = DIR_REG ? dir_q : dir_i;
  generate if (SPLIT) begin : g_split
    aes_dstage_a #(.MODE(MODE))               u_a (.dir(dir), .s_in(s_q),    .s_mid(mid_d));
    aes_dstage_b #(.MODE(MODE), .IS_LAST(0))  u_b (.dir(dir), .s_mid(mid_q), .k_in(k_q), .s_out(s_d));
  end else begin : g_full
    assign mid_d = '0;
    aes_dstage   #(.MODE(MODE), .IS_LAST(0))  u_d (.dir(dir), .s_in(s_q), .k_in(k_q), .s_out(s_d));
  end endgenerate
  aes_kstep #(.MODE(MODE)) u_k (.dir(dir), .rk_in(rk_q), .rcon(rcon_q), .rk_out(rk_d), .dk_out(dk_d));
endmodule
`define P5(name, M, DR, SP) \
module name (input logic clk, dir_i, input logic [127:0] s_i, k_i, rk_i, input logic [7:0] rcon_i, output logic [127:0] s_o, rk_o, dk_o); \
  aes_probe_v5 #(.MODE(M), .DIR_REG(DR), .SPLIT(SP)) u (.*); \
endmodule
`P5(probe5_encdec_mc, 1, 0, 0)
`P5(probe5_split_mc,  1, 0, 1)
`P5(probe5_dec,       2, 1, 0)
`P5(probe5_enc,       0, 1, 0)
`P5(probe5_encdec,    1, 1, 0)
