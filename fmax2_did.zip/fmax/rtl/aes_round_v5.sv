`timescale 1ns/1ps
// aes_round_v5.sv - split-round halves for the 2-stage-per-round option (reuses v4 functions' logic).
// Stage A: (Inv)ShiftRows + (Inv)SubBytes.   Stage B: (Inv)MixColumns + XOR registered key (or XOR only if last).
// A then B is exactly aes_dstage (v4); tb_round_v5 checks that over 303 full AES blocks.
module aes_dstage_a #(parameter int MODE = 1) (input logic dir, input logic [127:0] s_in, output logic [127:0] s_mid);
  import aes_sbox_pkg::*;
  logic dec;
  assign dec = (MODE == 2) ? 1'b1 : (MODE == 1) ? dir : 1'b0;
  function automatic logic [127:0] a_fn(input logic [127:0] s, input logic d);
    logic [127:0] sh, sb;
    for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++)
      sh[8*(r+4*c) +: 8] = d ? s[8*(r + 4*((c - r + 4) % 4)) +: 8] : s[8*(r + 4*((c + r) % 4)) +: 8];
    for (int k = 0; k < 16; k++) sb[8*k +: 8] = d ? isbox_lut(sh[8*k +: 8]) : sbox_lut(sh[8*k +: 8]);
    return sb;
  endfunction
  assign s_mid = a_fn(s_in, dec);
endmodule

module aes_dstage_b #(parameter int MODE = 1, parameter bit IS_LAST = 0) (
  input logic dir, input logic [127:0] s_mid, k_in, output logic [127:0] s_out);
  import aes_sbox_pkg::*;
  logic dec;
  assign dec = (MODE == 2) ? 1'b1 : (MODE == 1) ? dir : 1'b0;
  function automatic logic [7:0] xt(input logic [7:0] b); return {b[6:0],1'b0} ^ (b[7] ? 8'h1b : 8'h00); endfunction
  function automatic logic [127:0] mix(input logic [127:0] s);
    logic [127:0] m; logic [7:0] a0, a1, a2, a3;
    for (int c = 0; c < 4; c++) begin
      a0 = s[8*(4*c) +: 8]; a1 = s[8*(4*c+1) +: 8]; a2 = s[8*(4*c+2) +: 8]; a3 = s[8*(4*c+3) +: 8];
      m[8*(4*c)   +: 8] = xt(a0) ^ (xt(a1) ^ a1) ^ a2 ^ a3;
      m[8*(4*c+1) +: 8] = a0 ^ xt(a1) ^ (xt(a2) ^ a2) ^ a3;
      m[8*(4*c+2) +: 8] = a0 ^ a1 ^ xt(a2) ^ (xt(a3) ^ a3);
      m[8*(4*c+3) +: 8] = (xt(a0) ^ a0) ^ a1 ^ a2 ^ xt(a3);
    end
    return m;
  endfunction
  assign s_out = IS_LAST ? (s_mid ^ k_in) : dec ? (invmix(s_mid) ^ k_in) : (mix(s_mid) ^ k_in);
endmodule
