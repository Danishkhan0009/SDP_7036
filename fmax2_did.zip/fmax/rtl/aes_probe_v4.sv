`timescale 1ns/1ps
// aes_probe_v4.sv - reg -> (data stage | key step | InvMix of key) -> reg, all paths of one v4 stage.
module aes_probe_v4 #(parameter int MODE = 1) (
  input  logic clk, dir_i, input logic [127:0] s_i, k_i, rk_i, input logic [7:0] rcon_i,
  output logic [127:0] s_o, rk_o, dk_o);
  logic dir_q; logic [127:0] s_q, k_q, rk_q, s_d, rk_d, dk_d; logic [7:0] rcon_q;
  always_ff @(posedge clk) begin
    dir_q <= dir_i; s_q <= s_i; k_q <= k_i; rk_q <= rk_i; rcon_q <= rcon_i;
    s_o <= s_d; rk_o <= rk_d; dk_o <= dk_d;
  end
  aes_dstage #(.MODE(MODE), .IS_LAST(1'b0)) u_d (.dir(dir_q), .s_in(s_q), .k_in(k_q), .s_out(s_d));
  aes_kstep  #(.MODE(MODE)) u_k (.dir(dir_q), .rk_in(rk_q), .rcon(rcon_q), .rk_out(rk_d), .dk_out(dk_d));
endmodule
module probe4_enc    (input logic clk, dir_i, input logic [127:0] s_i, k_i, rk_i, input logic [7:0] rcon_i, output logic [127:0] s_o, rk_o, dk_o);
  aes_probe_v4 #(0) u (.*);
endmodule
module probe4_dec    (input logic clk, dir_i, input logic [127:0] s_i, k_i, rk_i, input logic [7:0] rcon_i, output logic [127:0] s_o, rk_o, dk_o);
  aes_probe_v4 #(2) u (.*);
endmodule
module probe4_encdec (input logic clk, dir_i, input logic [127:0] s_i, k_i, rk_i, input logic [7:0] rcon_i, output logic [127:0] s_o, rk_o, dk_o);
  aes_probe_v4 #(1) u (.*);
endmodule
