`timescale 1ns/1ps
// aes_round_v4.sv - Task 6 v4: round key registered one stage AHEAD of the data (key pipeline leads),
// decrypt uses the equivalent inverse cipher (InvMixColumns folded into the round key ahead of time).
// Every stage is then  [shift] -> S-box -> (Inv)MixColumns -> XOR registered key  with no key logic
// in series with the data path.  Byte k of a 128-bit word = bits [8k+7:8k] (Spec D12).
//
// aes_dstage : data part of one round.  MODE 0 = encrypt only, 1 = encrypt + decrypt (dir), 2 = decrypt only
//   encrypt round r : s_out = MixCol(Sub(Shift(s_in))) ^ k_in          k_in = rk[r]
//   decrypt round r : s_out = InvMix(InvSub(InvShift(s_in))) ^ k_in    k_in = InvMix(rk[r])  (r = 9..1)
//   last round      : no (Inv)MixColumns; k_in = rk[10] (enc) or rk[0] (dec)
// aes_kstep  : key part, runs ahead.  rk_out = next raw round key (forward or inverse schedule),
//              dk_out = InvMix(rk_in) = decrypt round key for a later stage.
module aes_dstage #(parameter int MODE = 1, parameter bit IS_LAST = 0) (
  input  logic dir, input logic [127:0] s_in, k_in, output logic [127:0] s_out);
  import aes_sbox_pkg::*;
  function automatic logic [7:0] xt(input logic [7:0] b); return {b[6:0],1'b0} ^ (b[7] ? 8'h1b : 8'h00); endfunction
  function automatic logic [7:0] get(input logic [127:0] v, input int k); return v[8*k +: 8]; endfunction
  function automatic logic [127:0] mix(input logic [127:0] s);
    logic [127:0] m; logic [7:0] a0, a1, a2, a3;
    for (int c = 0; c < 4; c++) begin
      a0 = get(s,4*c); a1 = get(s,4*c+1); a2 = get(s,4*c+2); a3 = get(s,4*c+3);
      m[8*(4*c)   +: 8] = xt(a0) ^ (xt(a1) ^ a1) ^ a2 ^ a3;
      m[8*(4*c+1) +: 8] = a0 ^ xt(a1) ^ (xt(a2) ^ a2) ^ a3;
      m[8*(4*c+2) +: 8] = a0 ^ a1 ^ xt(a2) ^ (xt(a3) ^ a3);
      m[8*(4*c+3) +: 8] = (xt(a0) ^ a0) ^ a1 ^ a2 ^ xt(a3);
    end
    return m;
  endfunction
  function automatic logic [127:0] round_fn(input logic [127:0] s, k, input logic d);
    logic [127:0] sh, sb, o;
    for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++)
      sh[8*(r+4*c) +: 8] = d ? get(s, r + 4*((c - r + 4) % 4)) : get(s, r + 4*((c + r) % 4));
    for (int k2 = 0; k2 < 16; k2++)
      sb[8*k2 +: 8] = d ? isbox_lut(get(sh, k2)) : sbox_lut(get(sh, k2));
    if (IS_LAST) o = sb ^ k;
    else if (d)  o = invmix(sb) ^ k;
    else         o = mix(sb) ^ k;
    return o;
  endfunction
  logic dec;
  assign dec = (MODE == 2) ? 1'b1 : (MODE == 1) ? dir : 1'b0;
  assign s_out = round_fn(s_in, k_in, dec);
endmodule

module aes_kstep #(parameter int MODE = 1) (
  input logic dir, input logic [127:0] rk_in, input logic [7:0] rcon,
  output logic [127:0] rk_out, dk_out);
  import aes_sbox_pkg::*;
  logic dec;
  assign dec = (MODE == 2) ? 1'b1 : (MODE == 1) ? dir : 1'b0;
  function automatic logic [127:0] key_step(input logic [127:0] rk, input logic [7:0] rc, input logic d);
    logic [31:0] w0, w1, w2, w3, n0, n1, n2, n3, t, k3;
    {w3, w2, w1, w0} = rk;
    if (!d) begin
      t  = {sbox_lut(w3[7:0]), sbox_lut(w3[31:24]), sbox_lut(w3[23:16]), sbox_lut(w3[15:8]) ^ rc};
      n0 = w0 ^ t; n1 = w1 ^ n0; n2 = w2 ^ n1; n3 = w3 ^ n2;
    end else begin
      k3 = w3 ^ w2;
      t  = {sbox_lut(k3[7:0]), sbox_lut(k3[31:24]), sbox_lut(k3[23:16]), sbox_lut(k3[15:8]) ^ rc};
      n3 = k3; n2 = w2 ^ w1; n1 = w1 ^ w0; n0 = w0 ^ t;
    end
    return {n3, n2, n1, n0};
  endfunction
  assign rk_out = key_step(rk_in, rcon, dec);
  assign dk_out = invmix(rk_in);
endmodule
